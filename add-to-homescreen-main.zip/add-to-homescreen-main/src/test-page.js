// browser.js

import AddToHomeScreen from './index';
window.AddToHomeScreen = AddToHomeScreen;
